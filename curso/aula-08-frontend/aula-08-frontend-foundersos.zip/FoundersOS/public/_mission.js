/* _mission.js - Mission Control: a tela de comando do OS.

   Vive fora do engine do grafo de proposito. O unico ponto de contato com o
   _core.js e o objeto publico window.BrainCore, que ja expoe tudo que a gente
   precisa: openViewer (abrir a nota no viewer que ja existe), jumpTo (saltar
   pro no do cliente no grafo) e S.skin (pra reusar o fundo hexagonal).

   Fluxo: FAB -> overlay -> um fetch em /api/mission -> render dos 3 blocos.
*/
'use strict';
(function () {
  const API = '/api/mission';
  let data = { mission: null, todos: [], meta: {} };
  let showDone = false;
  let loaded = false;

  // ---------- util ----------
  const $ = (sel, root) => (root || document).querySelector(sel);
  const el = (tag, cls, html) => {
    const n = document.createElement(tag);
    if (cls) n.className = cls;
    if (html != null) n.innerHTML = html;
    return n;
  };
  const esc = s => String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

  const nfInt = new Intl.NumberFormat('pt-BR');
  function todayISO() {
    const d = new Date();
    const p = n => String(n).padStart(2, '0');
    return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate());
  }
  function daysBetween(a, b) {
    return Math.round((new Date(b + 'T12:00:00') - new Date(a + 'T12:00:00')) / 864e5);
  }
  function fmtDue(due) {
    if (!due) return '';
    const t = todayISO(), diff = daysBetween(t, due);
    if (diff < 0) return diff === -1 ? 'venceu ontem' : 'atrasada ' + Math.abs(diff) + 'd';
    if (diff === 0) return 'hoje';
    if (diff === 1) return 'amanhã';
    if (diff <= 7) return 'em ' + diff + 'd';
    return due.slice(8, 10) + '/' + due.slice(5, 7);
  }

  // no brief o prazo mora numa coluna estreita: forma curta pra caber numa linha,
  // e a cor carrega o resto do recado (fmtDue continua servindo os chips do to-do).
  function briefDue(due) {
    if (!due) return { text: '--', cls: '' };
    const diff = daysBetween(todayISO(), due);
    if (diff < 0) return { text: '-' + Math.abs(diff) + 'd', cls: ' late' };
    if (diff === 0) return { text: 'hoje', cls: ' today' };
    if (diff === 1) return { text: 'amanhã', cls: '' };
    if (diff <= 7) return { text: 'em ' + diff + 'd', cls: '' };
    return { text: due.slice(8, 10) + '/' + due.slice(5, 7), cls: '' };
  }

  function toast(msg, isErr) {
    let t = $('#mc-toast');
    if (!t) { t = el('div', 'mc-toast'); t.id = 'mc-toast'; document.body.appendChild(t); }
    t.textContent = msg;
    t.className = 'mc-toast on' + (isErr ? ' err' : '');
    clearTimeout(t._tm);
    t._tm = setTimeout(() => { t.className = 'mc-toast' + (isErr ? ' err' : ''); }, 2600);
  }

  async function api(method, path, body) {
    const opt = { method, headers: { 'Content-Type': 'application/json' } };
    if (body !== undefined) opt.body = JSON.stringify(body);
    const r = await fetch(path, opt);
    const j = await r.json().catch(() => ({}));
    if (!r.ok || j.error) throw new Error(j.error || ('HTTP ' + r.status));
    return j;
  }

  // ---------- fundo: o mesmo hexagonal do grafo ----------
  function paintBackdrop() {
    const c = $('#mc-bg');
    if (!c) return;
    const dpr = Math.min(2, devicePixelRatio || 1);
    const W = innerWidth, H = innerHeight;
    // janela oculta/minimizada reporta 0x0: nao pinta agora, repinta quando voltar
    if (W < 2 || H < 2) return;
    c.width = W * dpr; c.height = H * dpr;
    c.style.width = W + 'px'; c.style.height = H + 'px';
    const g = c.getContext('2d');
    g.setTransform(dpr, 0, 0, dpr, 0, 0);
    const core = window.BrainCore;
    // reusa o backdrop do skin, pra tela nova pertencer ao mesmo mundo visual
    if (core && core.S && core.S.skin && core.S.skin.drawBackdrop) {
      try { core.S.skin.drawBackdrop(g, W, H, core.S); return; }
      catch (e) { /* cai no fallback */ }
    }
    g.fillStyle = getComputedStyle(document.body).getPropertyValue('--bg') || '#002316';
    g.fillRect(0, 0, W, H);
  }

  // ---------- Morning Brief ----------
  function briefSection(title, rows) {
    const sec = el('div', 'mc-brief-sec');
    sec.appendChild(el('div', 'mc-brief-h', esc(title)));
    if (!rows.length) { sec.appendChild(el('div', 'mc-empty', 'nada por aqui')); return sec; }
    for (const r of rows) sec.appendChild(r);
    return sec;
  }

  function renderBrief(m) {
    const card = el('div', 'mc-card');

    const agenda = (m.brief.agenda || []).map(a => {
      const row = el('div', 'mc-row');
      row.innerHTML = '<div class="mc-row-time">' + esc(a.time || '--') + '</div>'
        + '<div class="mc-row-main"><div class="mc-row-t">' + esc(a.title || '') + '</div>'
        + (a.kind ? '<div class="mc-row-s">' + esc(a.kind) + '</div>' : '') + '</div>';
      return row;
    });

    const fups = (m.brief.followups || []).map(f => {
      const row = el('div', 'mc-row');
      const c = f.contact || {};
      const bits = [];
      if (f.stage) bits.push(esc(f.stage));
      if (f.value) bits.push('R$ ' + nfInt.format(f.value));
      if (c.email) bits.push('<a href="mailto:' + esc(c.email) + '">' + esc(c.email) + '</a>');
      if (c.phone) bits.push(esc(c.phone));
      const d = briefDue(f.due);
      row.innerHTML = '<div class="mc-row-time' + d.cls + '" title="' + esc(fmtDue(f.due)) + '">' + esc(d.text) + '</div>'
        + '<div class="mc-row-main"><div class="mc-row-t">' + esc(f.deal || '') + '</div>'
        + (bits.length ? '<div class="mc-row-s">' + bits.join(' · ') + '</div>' : '') + '</div>';
      return row;
    });

    const mails = (m.brief.emails || []).filter(e => e.subject || e.from).map(e => {
      const row = el('div', 'mc-row');
      row.innerHTML = '<div class="mc-row-main"><div class="mc-row-t">' + esc(e.subject || '(sem assunto)') + '</div>'
        + '<div class="mc-row-s">' + esc(e.from || '') + (e.why ? ' · ' + esc(e.why) : '') + '</div></div>';
      return row;
    });

    const parei = (m.brief.onde_parei || []).map(t => {
      const row = el('div', 'mc-row');
      row.innerHTML = '<div class="mc-row-main"><div class="mc-row-t">' + esc(t) + '</div></div>';
      return row;
    });

    card.appendChild(briefSection('Agenda de hoje', agenda));
    card.appendChild(briefSection('Follow-ups', fups));
    card.appendChild(briefSection('E-mails que pedem resposta', mails));
    card.appendChild(briefSection('Onde parei', parei));
    return card;
  }

  // ---------- To-do ----------
  function laneOf(t) {
    if (t.status === 'done') return 'done';
    if (t.status === 'snoozed') return 'snoozed';
    if (!t.due) return 'noDate';
    const d = daysBetween(todayISO(), t.due);
    if (d < 0) return 'late';
    if (d === 0) return 'today';
    if (d <= 7) return 'week';
    return 'later';
  }

  function todoRow(t) {
    const row = el('div', 'mc-todo' + (t.status === 'done' ? ' done' : '') + (t.needs_review ? ' review' : ''));

    const chk = el('button', 'mc-check' + (t.status === 'done' ? ' on' : ''));
    chk.title = t.status === 'done' ? 'reabrir' : 'concluir';
    chk.onclick = () => patch(t.id, { status: t.status === 'done' ? 'open' : 'done' });
    row.appendChild(chk);

    const body = el('div', 'mc-todo-body');
    body.appendChild(el('div', 'mc-todo-t', esc(t.title)));

    const meta = el('div', 'mc-todo-meta');

    // chip de origem: a porta pro contexto no cerebro
    const o = t.origin || {};
    if (o.label) {
      const canOpen = !!o.note_path;
      const chip = el('button', 'mc-chip src-' + t.source + (canOpen ? ' act' : ''), esc(o.label));
      if (canOpen) {
        chip.title = 'abrir ' + o.note_path;
        chip.onclick = () => {
          if (window.BrainCore && BrainCore.openViewer) BrainCore.openViewer(o.note_path);
          else toast('viewer indisponível', true);
        };
      }
      meta.appendChild(chip);
    }

    // chip do cliente: fecha o painel e salta pro no dele no grafo
    if (o.client) {
      const chip = el('button', 'mc-chip client act', esc(o.client));
      chip.title = 'ver ' + o.client + ' no grafo';
      chip.onclick = () => {
        close();
        setTimeout(() => {
          if (window.BrainCore && BrainCore.jumpTo) BrainCore.jumpTo('clientes/' + o.client);
        }, 260);
      };
      meta.appendChild(chip);
    }

    if (t.due) {
      const d = daysBetween(todayISO(), t.due);
      const cls = d < 0 ? ' due-late' : d === 0 ? ' due-today' : '';
      meta.appendChild(el('span', 'mc-chip' + cls, esc(fmtDue(t.due))));
    }
    if (t.status === 'snoozed' && t.snooze_until) {
      meta.appendChild(el('span', 'mc-chip', 'adiada p/ ' + esc(fmtDue(t.snooze_until))));
    }
    if (t.needs_review) {
      const chip = el('span', 'mc-chip rev', 'extraída por IA');
      chip.title = 'veio de extração automática, confira antes de confiar';
      meta.appendChild(chip);
    }
    if (meta.childNodes.length) body.appendChild(meta);
    row.appendChild(body);

    const acts = el('div', 'mc-todo-acts');
    if (t.status !== 'done') {
      const snooze = el('button', 'mc-icon-btn', '&rsaquo;&rsaquo;');
      snooze.title = 'adiar pra amanhã';
      snooze.onclick = () => {
        const d = new Date(); d.setDate(d.getDate() + 1);
        patch(t.id, { snooze_until: d.toISOString().slice(0, 10) });
      };
      acts.appendChild(snooze);
    }
    const del = el('button', 'mc-icon-btn danger', '&times;');
    del.title = t.needs_review ? 'isso não é tarefa, descartar' : 'descartar';
    del.onclick = () => remove(t.id);
    acts.appendChild(del);
    row.appendChild(acts);

    return row;
  }

  function renderTodos(todos) {
    const card = el('div', 'mc-card');

    // captura rapida
    const add = el('div', 'mc-add');
    const input = el('input');
    input.type = 'text';
    input.placeholder = 'Adicionar tarefa e pressionar Enter';
    input.id = 'mc-add-input';
    const btn = el('button', null, 'ADD');
    const submit = async () => {
      const v = input.value.trim();
      if (!v) return;
      input.value = '';
      try { await api('POST', '/api/todo', { title: v, due: todayISO() }); await load(); toast('tarefa criada'); }
      catch (e) { toast(e.message, true); input.value = v; }
    };
    input.addEventListener('keydown', e => {
      if (e.key === 'Enter') { e.preventDefault(); submit(); }
      if (e.key === 'Escape') { e.stopPropagation(); input.blur(); }
    });
    btn.onclick = submit;
    add.appendChild(input); add.appendChild(btn);
    card.appendChild(add);

    const lanes = { late: [], today: [], week: [], later: [], noDate: [], snoozed: [], done: [] };
    for (const t of todos) lanes[laneOf(t)].push(t);

    const order = [
      ['late', 'Atrasadas', true],
      ['today', 'Hoje', false],
      ['week', 'Esta semana', false],
      ['later', 'Depois', false],
      ['noDate', 'Sem prazo', false],
      ['snoozed', 'Adiadas', false],
    ];

    let anyOpen = false;
    for (const [key, label, hot] of order) {
      const list = lanes[key];
      if (!list.length) continue;
      anyOpen = true;
      const h = el('div', 'mc-lane-h' + (hot ? ' hot' : ''));
      h.innerHTML = esc(label) + '<span class="mc-count">' + list.length + '</span>';
      card.appendChild(h);
      for (const t of list) card.appendChild(todoRow(t));
    }

    if (!anyOpen) {
      card.appendChild(el('div', 'mc-empty', lanes.done.length
        ? 'Tudo concluído. Dia limpo.'
        : 'Nenhuma tarefa. Adicione uma acima ou clique em Sincronizar.'));
    }

    if (lanes.done.length) {
      const tg = el('button', 'mc-done-toggle', (showDone ? 'esconder' : 'mostrar') + ' ' + lanes.done.length + ' concluída' + (lanes.done.length > 1 ? 's' : ''));
      tg.onclick = () => { showDone = !showDone; render(); };
      card.appendChild(tg);
      if (showDone) {
        for (const t of lanes.done.sort((a, b) => (b.done_at || '').localeCompare(a.done_at || ''))) card.appendChild(todoRow(t));
      }
    }
    return card;
  }

  // ---------- acoes ----------
  async function patch(id, body) {
    try { await api('PATCH', '/api/todo', { id, ...body }); await load(); }
    catch (e) { toast(e.message, true); }
  }
  async function remove(id) {
    try { await api('DELETE', '/api/todo?id=' + encodeURIComponent(id)); await load(); toast('descartada'); }
    catch (e) { toast(e.message, true); }
  }
  async function runIngest() {
    toast('sincronizando com o brain...');
    try {
      const r = await api('POST', '/api/mission/ingest', { days: 2 });
      await load();
      toast(r.added ? r.added + ' tarefa(s) nova(s)' : 'nada novo pra trazer');
    } catch (e) { toast(e.message, true); }
  }

  // ---------- render ----------
  function render() {
    const inner = $('#mc-inner');
    if (!inner) return;
    const m = data.mission || { brief: {}, missing: true };
    inner.innerHTML = '';

    // topo
    const top = el('div', 'mc-top');
    const back = el('button', 'mc-back');
    back.innerHTML = '<span class="mc-back-arrow">&#9666;</span>'
      + '<div><div><span class="mc-back-name">Founders</span><span class="mc-back-os">OS</span></div>'
      + '<div class="mc-back-sub">voltar pro grafo do cérebro</div></div>';
    back.onclick = close;
    top.appendChild(back);

    const right = el('div', 'mc-top-right');
    const now = new Date();
    const dias = ['domingo', 'segunda', 'terça', 'quarta', 'quinta', 'sexta', 'sábado'];
    const clock = el('div', 'mc-clock');
    clock.innerHTML = '<div class="mc-clock-d">' + String(now.getDate()).padStart(2, '0') + '/'
      + String(now.getMonth() + 1).padStart(2, '0') + '</div>'
      + '<div class="mc-clock-s">' + dias[now.getDay()] + '</div>';
    const bIng = el('button', 'act', 'Sincronizar');
    bIng.title = 'absorve a caixa de entrada do brain e as pendências dos diários recentes (não duplica, não apaga nada)';
    bIng.onclick = runIngest;
    const bRef = el('button', 'act', 'Atualizar');
    bRef.onclick = () => load().then(() => toast('atualizado'));
    right.appendChild(bIng); right.appendChild(bRef); right.appendChild(clock);
    top.appendChild(right);
    inner.appendChild(top);

    // aviso quando o estado ainda nao foi escrito por nenhuma rotina
    if (m.missing) {
      inner.appendChild(el('div', 'mc-warn',
        '<div>&#9888;</div><div><b>O Morning Brief ainda não tem fonte.</b> Nenhuma rotina escreveu '
        + '<code>state/mission.json</code> ainda. Copie <code>state/mission.example.json</code> pra começar, '
        + 'ou rode a sua rotina de refresh. As tarefas abaixo funcionam normalmente.</div>'));
    }

    // To-do e Morning Brief, lado a lado. O to-do vem primeiro por ser o coracao.
    const cols = el('div', 'mc-cols');

    const cTodo = el('div');
    const openCount = data.todos.filter(t => t.status !== 'done').length;
    const hTodo = el('div', 'mc-h');
    hTodo.innerHTML = 'To-do<span class="mc-h-note">' + openCount + ' em aberto</span>';
    cTodo.appendChild(hTodo);
    cTodo.appendChild(renderTodos(data.todos));

    const cBrief = el('div');
    cBrief.appendChild(el('div', 'mc-h', 'Morning Brief'));
    cBrief.appendChild(renderBrief(m));

    cols.appendChild(cTodo);
    cols.appendChild(cBrief);
    inner.appendChild(cols);
  }

  async function load() {
    try {
      const j = await api('GET', API);
      data = j;
      loaded = true;
    } catch (e) {
      toast('não consegui ler o estado: ' + e.message, true);
    }
    render();
  }

  // ---------- abrir / fechar ----------
  function open() {
    const root = $('#mc-root');
    document.body.classList.add('mc-open');
    root.classList.add('on');
    window.__mcPaused = true;              // pausa o loop do grafo (economia de CPU)
    paintBackdrop();
    // forca o reflow e sobe a opacidade na hora. Nao usamos rAF aqui de proposito:
    // com a janela oculta o rAF nao dispara e o painel ficaria invisivel.
    void root.offsetHeight;
    root.classList.add('in');
    if (!loaded) render();                 // pinta a casca antes do fetch
    load().then(() => {
      const sc = $('#mc-scroll');
      if (sc) sc.scrollTop = 0;            // abre sempre do topo, depois do render
      const i = $('#mc-add-input');
      if (i) i.focus({ preventScroll: true });
    });
  }

  function close() {
    const root = $('#mc-root');
    root.classList.remove('in');
    document.body.classList.remove('mc-open');
    window.__mcPaused = false;
    setTimeout(() => root.classList.remove('on'), 240);
  }

  function toggle() { $('#mc-root').classList.contains('on') ? close() : open(); }

  // ---------- boot ----------
  addEventListener('DOMContentLoaded', () => {
    const root = el('div');
    root.id = 'mc-root';
    root.innerHTML = '<canvas id="mc-bg"></canvas><div id="mc-scroll"><div id="mc-inner"></div></div>';
    document.body.appendChild(root);

    const fab = el('button', 'fab', '◈ MISSION CONTROL');
    fab.id = 'fab-mission';
    fab.onclick = toggle;
    document.body.appendChild(fab);

    // Esc fecha o painel antes de o grafo tratar a tecla (capture)
    addEventListener('keydown', e => {
      const open = $('#mc-root').classList.contains('on');
      if (e.key === 'Escape' && open) {
        const drawer = document.getElementById('brain-viewer');
        if (drawer && drawer.classList.contains('open')) return; // deixa fechar o viewer primeiro
        e.stopPropagation(); e.preventDefault(); close(); return;
      }
      const typing = /^(INPUT|TEXTAREA)$/.test(document.activeElement.tagName);
      if (!typing && (e.key === 'm' || e.key === 'M')) { e.preventDefault(); toggle(); }
    }, true);

    const repaintIfOpen = () => { if ($('#mc-root').classList.contains('on')) paintBackdrop(); };
    addEventListener('resize', repaintIfOpen);
    // janela voltou de oculta: agora ha dimensao pra pintar o fundo
    document.addEventListener('visibilitychange', () => { if (!document.hidden) repaintIfOpen(); });
  });

  window.MissionControl = { open, close, toggle, load, get data() { return data; } };
})();
