# FoundersOS - Second Brain

> Acelere a cognição operacional e centralize o conhecimento estratégico da sua empresa em um sistema de gestão de conhecimento interativo e de alta performance.

O **FoundersOS** é um sistema completo de gestão de conhecimento e indexação de dados projetado para equipes de vendas B2B, operações e agentes de IA. Ele transforma pastas de arquivos, notas soltas e integrações em uma base de conhecimento unificada — mapeando processos, playbooks e ferramentas de forma inteligente e acionável por meio de um grafo dinâmico em formato orbital.

---

## 💡 Por que o Second Brain?

Empresas de rápido crescimento acumulam conhecimento disperso: playbooks de vendas, informações de clientes, scripts de automação e rotinas comerciais. O **Second Brain OS** resolve esse problema organizando e estruturando esse conhecimento na metodologia proprietária **ARMS**, tornando a busca de informações instantânea tanto para humanos quanto para copilotos de IA.

---

## 🏗️ Metodologia ARMS (Camadas de Conhecimento)

O sistema classifica e exibe toda a inteligência da empresa em 4 pilares:

* **`A` Applications (Aplicações):** Ferramentas e conectores ativos (Notion, CRM Pipedrive, Gmail, HubSpot) integrados à operação.
* **`R` Routines (Rotinas):** Processos automáticos e recorrentes executados na ponta (como monitoramento de conteúdo, crons de prospecção).
* **`M` Memory (Memória):** Playbooks de vendas, documentação de produtos, registros de reuniões e base de conhecimento.
* **`S` Skills (Habilidades):** Capacidades operacionais que os agentes de IA possuem para executar tarefas sobre a base.

---

## 🔥 Principais Diferenciais Comerciais

### 🎨 Visualização Orbital Dinâmica
Navegue pelo seu ecossistema de conhecimento por meio de um gráfico orbital interativo baseado em órbitas, anéis e cores de departamentos (Clientes, Conteúdo, Aprendizado, Infraestrutura, etc.).

### ⚡ Busca de Ultra-Alta Performance
Busque e conecte referências entre mais de 40.000 arquivos de forma instantânea. O walker classificador mapeia referências cruzadas e links markdown em milissegundos.

### 🧠 CLI de Memória Integrado (`brain.js`)
Armazene e recupere fatos e dados diretamente do terminal de forma ágil para alimentar contextos de IA.
```bash
node brain.js store "Meta do time comercial para Q3 é 150k" --name comercial-q3
node brain.js recall "comercial"
```

### 🔒 Privacidade e Segurança por Padrão
Filtros inteligentes ignoram automaticamente arquivos confidenciais (`.env`, `.pem`, chaves de API, credenciais) e isolam dados confidenciais a nível de departamento, garantindo total conformidade de segurança.

### 🎯 Mission Control (segunda tela)
Além do grafo, o app tem uma tela de comando que responde duas perguntas: **como está meu dia e o que eu preciso fazer agora.** Abre pelo botão `◈ MISSION CONTROL`, volta pro grafo clicando no logo, e alterna pela tecla `M`.

- **Morning Brief:** agenda do dia, follow-ups com contato à vista, e-mails que exigem resposta e as pendências que ficaram de ontem.
- **To-do inteligente:** entrada manual mais ingestão automática das pendências do diário do vault. Cada tarefa carrega a origem: clicar nela abre a nota no viewer, e clicar no cliente salta pro nó dele no grafo.

**O app continua sem falar com API externa.** Ele lê `state/mission.json`, escrito por quem tem as credenciais (um agente, um cron, um n8n). O contrato está em `state/mission.example.json`. As convenções de pasta do seu vault são configuráveis no bloco `missionControl` do `config/workspace.json`.

---

## 🛠️ Instalação e Configuração Rápida

### 1. Duplique as Configurações de Template
Para configurar o seu ambiente de pastas local, copie os modelos de configuração padrão na pasta `config/`:

**No Windows (PowerShell):**
```powershell
Get-ChildItem config/*.example | ForEach-Object { Copy-Item $_.FullName $_.FullName.Replace(".example", "") }
```

**No Linux/macOS:**
```bash
cp config/workspace.json.example config/workspace.json
cp config/departments.json.example config/departments.json
cp config/apps.json.example config/apps.json
cp config/routines.json.example config/routines.json
cp config/access-overrides.json.example config/access-overrides.json
cp config/agents.json.example config/agents.json
cp config/tweaks.json.example config/tweaks.json
```

### 2. Configure seus Caminhos de Leitura
Edite o arquivo `config/workspace.json` para apontar o caminho raiz (`root`) que o Second Brain deve escanear, e personalize os nomes das suas pastas prioritárias em `visibleRoots`.

### 3. Inicie o Second Brain OS
Instale as dependências padrão (se houver) e rode o servidor local:
```bash
node server.js
```
Acesse no seu navegador: **[http://localhost:5210](http://localhost:5210)**

---

## 📈 Transforme a sua Operação Comercial com a Playbook Lab

Melhore a produtividade do time, acelere o onboarding de novos SDRs/Vendedores e otimize o contexto dos seus agentes de Inteligência Artificial usando um cérebro digital unificado.

👉 **[Agende uma demonstração estratégica com o time da Playbook Lab](https://playbooklab.com.br)**
